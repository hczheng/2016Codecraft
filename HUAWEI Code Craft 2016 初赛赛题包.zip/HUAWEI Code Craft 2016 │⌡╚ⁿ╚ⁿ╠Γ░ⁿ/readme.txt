SDK-gcc路径下为c/c++版本的SDK，具体使用方法参看该路径下的readme。
SDK-java路径下为java版本的SDK，具体使用方法参看该路径下的readme。
test-case路径下为题目描述中的测试例，其中topo.csv为图的信息文件，demand.csv为路径信息文件，sample_result.csv为输出结果文件样例。可以参考这几个文件的格式自行设计测试例。